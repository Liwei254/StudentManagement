package com.example.studentmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    EditText username,password;
    Button cancel,login;
    String strname,strpass;
    Bean bean;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username=findViewById(R.id.firstname);
        password=findViewById(R.id.password);
        cancel=findViewById(R.id.cancel_button);
        login=findViewById(R.id.login);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                username.setText("");
                password.setText("");
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                strname=username.getText().toString().trim();
                strpass=password.getText().toString().trim();
                FirebaseDatabase database = FirebaseDatabase.getInstance();
                DatabaseReference reference = database.getReference("Users");
                reference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        boolean found =false;
                        for(DataSnapshot snap:snapshot.getChildren()){
                            Bean2 user=snap.getValue(Bean2.class);

                            if (user != null && user.getFirstname().equals(strname) && user.getPassword().equals(strpass)) {
                                found = true;
                                break;
                            }
                        }

                        if (found) {
                            Intent intent = new Intent(MainActivity.this, HomeActivity.class); // or your target activity
                            startActivity(intent);
                        } else {
                            // Show error
                            username.setError("Invalid email or password");
                            password.setError("Invalid email or password");
                        }
                    }


                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.e("FirebaseError", "Error code: " + error.getCode() + ", message: " + error.getMessage());
                        Toast.makeText(getApplicationContext(), "Failed to load data: " + error.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });

            }
        });

    }


    public void register(View view) {
        Intent intent =new Intent(getApplicationContext(), registration.class);
        startActivity(intent);
    }

    public void cancel(View view) {
    }
}